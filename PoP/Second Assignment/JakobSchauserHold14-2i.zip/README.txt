  _____      _____              __ _                     _               ___  
 |  __ \    |  __ \      /\    / _| |                   (_)             |__ \ 
 | |__) |__ | |__) |    /  \  | |_| | _____   _____ _ __ _ _ __   __ _     ) |
 |  ___/ _ \|  ___/    / /\ \ |  _| |/ _ \ \ / / _ \ '__| | '_ \ / _` |   / / 
 | |  | (_) | |       / ____ \| | | |  __/\ V /  __/ |  | | | | | (_| |  / /_ 
 |_|   \___/|_|      /_/    \_\_| |_|\___| \_/ \___|_|  |_|_| |_|\__  | |____|
                                                                  __/ |       
                                                                 |___/        

For compiling the LaTeX, simply use any LaTeX to pdf converter on JakobSchauserHold14-2i.tex.
When running the F# code, compile the 2i1.fsx down to a binary and run that using mono.